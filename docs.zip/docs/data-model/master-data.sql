-- ═══════════════════════════════════════════════════════════════════════════
--  PROPOSED MASTER-DATA SCHEMA — the tables this platform does not have yet.
--
--  NOT WIRED IN. This is a design artefact to review, not a migration to run.
--  When adopted it belongs in nextxr-ontology/db/schema.py's `DDL` dict, in the
--  house idiom: {id} {str} {json} {ts_now} {serial_pk} placeholders, every
--  statement IF NOT EXISTS, ensure() safe on every boot. Written here as plain
--  MySQL so it can be read and argued with before anyone commits to it.
--
--  WHAT THIS CLOSES
--  ----------------
--  Today the platform has `measurements(tenant_id, asset_id, signal, ts, value,
--  unit, quality, source)` and nothing above it. That means:
--    · a sensor swap is invisible, so it lands as a step change in the trend and
--      silently corrupts every learned baseline;
--    · sensor health analytics is structurally impossible — there is no sensor
--      to be healthy;
--    · thresholds live as literals inside nxr:monitoringRules JSON, so no limit
--      has a basis, an owner, an approval or a history;
--    · an operator's verdict on an alert is never recorded, so there are no
--      labels and precision can never be measured.
--
--  THE CHEAP ADOPTION PATH
--  -----------------------
--  `measurement_point` carries BOTH the canonical point_id AND the existing
--  (asset_id, signal) pair. So the historian keeps its current primary key and
--  its current writers, and the model layer joins onto it. No telemetry
--  migration, no rewrite of ingest — the four-level sensor model arrives as a
--  join, not as a breaking change. Only once that is stable is it worth adding
--  point_id to the measurement rows themselves.
-- ═══════════════════════════════════════════════════════════════════════════


-- ── SENSOR LEVEL 2: the catalogue ──────────────────────────────────────────
-- The degradation MODEL attaches here (to the type). The metrological columns
-- are not paperwork: response_t90_s sets the L2 stuck-detection window,
-- uncertainty_json becomes Σ in the L5 reconciliation, and
-- drift_spec_pct_fs_per_year is the Bayesian prior for the per-instance drift fit.
CREATE TABLE IF NOT EXISTS sensor_type (
    sensor_type_id            VARCHAR(191) CHARACTER SET ascii PRIMARY KEY,
    tenant_id                 VARCHAR(191) CHARACTER SET ascii,   -- NULL = platform catalogue
    transducer_family         VARCHAR(64)  NOT NULL,              -- drives the degradation physics
    degradation_regime        VARCHAR(32)  NOT NULL,              -- consumable | drifting | step-failure
    manufacturer              VARCHAR(191) NOT NULL DEFAULT '',
    model                     VARCHAR(191) NOT NULL DEFAULT '',
    part_number               VARCHAR(191) NOT NULL DEFAULT '',
    measurement_principle     VARCHAR(191) NOT NULL DEFAULT '',
    output_type               VARCHAR(32)  NOT NULL DEFAULT '',
    range_low                 DOUBLE,
    range_high                DOUBLE,
    unit_code                 VARCHAR(64)  NOT NULL DEFAULT '',   -- UCUM/QUDT
    accuracy_class            VARCHAR(64)  NOT NULL DEFAULT '',
    uncertainty_json          JSON,                               -- GUM components + combined u_c
    resolution                DOUBLE,
    response_t90_s            DOUBLE,
    drift_spec_pct_fs_per_year DOUBLE,
    operating_envelope_json   JSON,
    compensation_inputs_json  JSON,
    cross_sensitivity_json    JSON,                               -- the plausible-but-wrong reading
    expected_life_months      INT,
    mtbf_hours                INT,
    cal_interval_default_days INT,
    protection_rating         VARCHAR(64)  NOT NULL DEFAULT '',
    created_at                DATETIME(6)  NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
);


-- ── SENSOR LEVEL 3: the serialised device ──────────────────────────────────
-- The degradation STATE attaches here. `replaces` / `replaced_by` are the
-- lineage that lets a trend survive a swap instead of breaking at it.
CREATE TABLE IF NOT EXISTS sensor_instance (
    sensor_id            VARCHAR(191) CHARACTER SET ascii PRIMARY KEY,
    tenant_id            VARCHAR(191) CHARACTER SET ascii NOT NULL,
    sensor_type_id       VARCHAR(191) CHARACTER SET ascii NOT NULL,
    serial               VARCHAR(191) NOT NULL DEFAULT '',
    firmware_version     VARCHAR(64)  NOT NULL DEFAULT '',   -- firmware silently rescales things
    install_ts           DATETIME(6),
    removal_ts           DATETIME(6),
    removal_reason       VARCHAR(255) NOT NULL DEFAULT '',
    replaces_sensor_id   VARCHAR(191) CHARACTER SET ascii,
    cal_last_ts          DATETIME(6),
    cal_due_ts           DATETIME(6),
    cal_offset           DOUBLE,
    cal_gain             DOUBLE,
    cumulative_exposure_json JSON,                           -- hours, cycles, dose, time-above-temp
    health_index         DOUBLE,
    ne107_status         VARCHAR(32) NOT NULL DEFAULT 'OK',  -- the ONE canonical status enum
    updated_at           DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    INDEX idx_sensor_instance_tenant (tenant_id, sensor_type_id),
    INDEX idx_sensor_instance_cal_due (tenant_id, cal_due_ts)
);


-- ── SENSOR LEVEL 4: the measurement point ──────────────────────────────────
-- Stable for the life of the plant. THE trend, the baseline and the thresholds
-- all belong here, not to whichever device is plugged in this year.
--
-- `asset_id` + `signal` are the bridge to the existing historian: they mirror
-- the measurements table's key columns so nothing has to be migrated on day one.
CREATE TABLE IF NOT EXISTS measurement_point (
    point_id             VARCHAR(191) CHARACTER SET ascii PRIMARY KEY,
    tenant_id            VARCHAR(191) CHARACTER SET ascii NOT NULL,
    asset_id             VARCHAR(256) CHARACTER SET ascii NOT NULL,   -- joins measurements.asset_id
    signal               VARCHAR(512) CHARACTER SET ascii NOT NULL,   -- joins measurements.signal
    tag                  VARCHAR(255) NOT NULL DEFAULT '',            -- KKS / ISA-5.1 / Brick / OCPP / Redfish
    asset_class_iri      VARCHAR(512) NOT NULL DEFAULT '',
    functional_location  VARCHAR(255) NOT NULL DEFAULT '',            -- survives equipment swaps
    observable_property  VARCHAR(512) NOT NULL DEFAULT '',            -- sosa:ObservableProperty IRI
    canonical_unit       VARCHAR(64)  NOT NULL DEFAULT '',            -- UCUM. Convert at the edges only.
    purpose_class        VARCHAR(32)  NOT NULL DEFAULT 'monitoring',  -- control|monitoring|safety|regulatory|analytics
    safety_class         VARCHAR(16)  NOT NULL DEFAULT 'none',
    sil                  VARCHAR(8),
    expected_interval_ms INT,
    deadband             DOUBLE,
    plausible_min        DOUBLE,                                      -- PHYSICAL limit, not the sensor's range
    plausible_max        DOUBLE,
    slew_limit_per_s     DOUBLE,
    expected_by_mode_json JSON,                                       -- {"steady":[22,26],"standby":[18,35]}
    redundancy_group_id  VARCHAR(191) CHARACTER SET ascii,
    voting_role          VARCHAR(32) NOT NULL DEFAULT 'none',
    detects_json         JSON,                                        -- failure-mode ids. Empty = storage cost.
    installation_context_json JSON,
    protocol_binding_json JSON,                                       -- register, scale, byte order, deadband
    min_trust_required   DOUBLE NOT NULL DEFAULT 0.5,
    status               VARCHAR(32) NOT NULL DEFAULT 'PLANNED',
    created_at           DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    UNIQUE KEY uq_point_signal (tenant_id, asset_id, signal),
    INDEX idx_point_class (tenant_id, asset_class_iri),
    INDEX idx_point_purpose (tenant_id, purpose_class)
);


-- ── THE JOIN THAT SURVIVES A SENSOR SWAP ───────────────────────────────────
-- Time-boxed: which device served which point, when. Query the historian for a
-- trend and this table tells you exactly where the hardware changed underneath
-- it — which is the difference between "the machine degraded in March" and
-- "we fitted a different probe in March".
CREATE TABLE IF NOT EXISTS point_sensor_assignment (
    assignment_id  VARCHAR(191) CHARACTER SET ascii PRIMARY KEY,
    tenant_id      VARCHAR(191) CHARACTER SET ascii NOT NULL,
    point_id       VARCHAR(191) CHARACTER SET ascii NOT NULL,
    sensor_id      VARCHAR(191) CHARACTER SET ascii NOT NULL,
    channel        VARCHAR(64) NOT NULL DEFAULT '',
    valid_from     DATETIME(6) NOT NULL,
    valid_to       DATETIME(6),                                  -- NULL = current
    INDEX idx_psa_point (tenant_id, point_id, valid_from),
    INDEX idx_psa_sensor (tenant_id, sensor_id, valid_from)
);


-- ── CALIBRATION ────────────────────────────────────────────────────────────
-- as_found is the ONLY direct measurement of accumulated drift anyone will ever
-- hand you, and most organisations record only as_left and throw it away. Both
-- columns are NOT NULL-able by intent: a record without as_found is not a
-- calibration record, it is an adjustment note.
CREATE TABLE IF NOT EXISTS calibration_record (
    calibration_id   VARCHAR(191) CHARACTER SET ascii PRIMARY KEY,
    tenant_id        VARCHAR(191) CHARACTER SET ascii NOT NULL,
    sensor_id        VARCHAR(191) CHARACTER SET ascii NOT NULL,
    performed_ts     DATETIME(6) NOT NULL,
    performed_by     VARCHAR(191) NOT NULL DEFAULT '',
    procedure_ref    VARCHAR(255) NOT NULL DEFAULT '',
    standard_ref     VARCHAR(255) NOT NULL DEFAULT '',        -- ISO/IEC 17025 traceability chain
    as_found_json    JSON,                                    -- per test point: applied vs read
    as_left_json     JSON,
    offset_applied   DOUBLE,
    gain_applied     DOUBLE,
    passed           TINYINT(1) NOT NULL DEFAULT 1,
    next_due_ts      DATETIME(6),                             -- modelled, not hardcoded (see §8)
    INDEX idx_cal_sensor (tenant_id, sensor_id, performed_ts DESC)
);


-- ── THRESHOLDS AS GOVERNED OBJECTS ─────────────────────────────────────────
-- Bitemporal by `effective_from`/`effective_to` + `version`, so you can always
-- reconstruct which limit was in force at the moment an operator acted.
--
-- `basis` and `corrective_action` are NOT decoration. ISA-18.2's acceptance test
-- is "what does the operator DO when this fires?" — a threshold that cannot
-- answer it is a nuisance alarm with a job title, and should be deleted.
--
-- `min_trust_required` is the join to the verification layer: this limit will
-- not fire on telemetry the platform does not trust.
CREATE TABLE IF NOT EXISTS threshold (
    threshold_id      VARCHAR(191) CHARACTER SET ascii NOT NULL,
    version           INT NOT NULL DEFAULT 1,
    tenant_id         VARCHAR(191) CHARACTER SET ascii,          -- NULL = platform default
    scope_type        VARCHAR(32) NOT NULL,                      -- global|asset_class|asset|point
    scope_ref         VARCHAR(512) NOT NULL,
    behavior_id       VARCHAR(191) CHARACTER SET ascii NOT NULL DEFAULT '',  -- ties to the behaviour registry
    condition_type    VARCHAR(32) NOT NULL,                      -- one of the 8 classes
    expression        TEXT NOT NULL,                             -- declarative + executable, never code
    limits_json       JSON NOT NULL,                             -- {"lo":..,"hi":..,"hihi":..}
    unit_code         VARCHAR(64) NOT NULL DEFAULT '',
    applicability_json JSON,                                     -- mode, load band, ambient, time window
    hysteresis        DOUBLE,
    on_delay_s        INT,
    off_delay_s       INT,
    latching          TINYINT(1) NOT NULL DEFAULT 0,
    priority          VARCHAR(16) NOT NULL DEFAULT 'low',
    suppression_json  JSON,                                      -- shelving, mode-based, first-out
    min_trust_required DOUBLE NOT NULL DEFAULT 0.5,
    basis             VARCHAR(64) NOT NULL,                      -- standard|oem|regulation|statistical|judgement
    basis_reference   VARCHAR(512) NOT NULL DEFAULT '',
    consequence       TEXT,
    corrective_action TEXT,
    time_to_respond_s INT,
    owner             VARCHAR(191) NOT NULL DEFAULT '',
    approved_by       VARCHAR(191),
    approved_at       DATETIME(6),
    review_due        DATETIME(6),
    effective_from    DATETIME(6) NOT NULL,
    effective_to      DATETIME(6),                               -- NULL = in force
    PRIMARY KEY (threshold_id, version),
    INDEX idx_threshold_scope (tenant_id, scope_type, scope_ref(191)),
    INDEX idx_threshold_effective (tenant_id, effective_from, effective_to)
);


-- ── ALARMS AND — the important half — THE OPERATOR'S VERDICT ───────────────
CREATE TABLE IF NOT EXISTS alarm_occurrence (
    occurrence_id   VARCHAR(191) CHARACTER SET ascii PRIMARY KEY,
    tenant_id       VARCHAR(191) CHARACTER SET ascii NOT NULL,
    threshold_id    VARCHAR(191) CHARACTER SET ascii NOT NULL,
    threshold_version INT NOT NULL,                     -- which limit actually fired
    point_id        VARCHAR(191) CHARACTER SET ascii,
    asset_id        VARCHAR(256) CHARACTER SET ascii,
    incident_id     VARCHAR(191) CHARACTER SET ascii,   -- the nxr:Incident it grouped into
    raised_ts       DATETIME(6) NOT NULL,
    value_at_raise  DOUBLE,
    trust_at_raise  DOUBLE,                             -- was the data any good when it fired?
    operating_mode  VARCHAR(64),
    ack_ts          DATETIME(6),
    ack_by          VARCHAR(191),
    cleared_ts      DATETIME(6),
    shelved         TINYINT(1) NOT NULL DEFAULT 0,
    suppressed_by   VARCHAR(191),
    resolution_code VARCHAR(64),
    INDEX idx_alarm_tenant_ts (tenant_id, raised_ts DESC),
    INDEX idx_alarm_incident (tenant_id, incident_id)
);

-- The highest-leverage table in this file, and the one almost every platform
-- omits. Without it: no labels, no measurable precision, no way to tune a
-- threshold with evidence, and no supervised model — ever. One tap in the UI.
CREATE TABLE IF NOT EXISTS alert_disposition (
    disposition_id  VARCHAR(191) CHARACTER SET ascii PRIMARY KEY,
    tenant_id       VARCHAR(191) CHARACTER SET ascii NOT NULL,
    occurrence_id   VARCHAR(191) CHARACTER SET ascii,
    incident_id     VARCHAR(191) CHARACTER SET ascii,
    verdict         VARCHAR(32) NOT NULL,               -- true-positive|false-positive|nuisance|unknown
    cause_text      TEXT,
    judged_by       VARCHAR(191) NOT NULL,
    judged_ts       DATETIME(6) NOT NULL,
    override_reason TEXT,                               -- why the operator disagreed with the twin
    INDEX idx_disposition_tenant (tenant_id, judged_ts DESC),
    INDEX idx_disposition_occurrence (tenant_id, occurrence_id)
);


-- ── DERIVED STATE ──────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS health_state (
    subject_urn     VARCHAR(512) CHARACTER SET ascii NOT NULL,   -- asset, component OR sensor
    tenant_id       VARCHAR(191) CHARACTER SET ascii NOT NULL,
    assessed_ts     DATETIME(6) NOT NULL,
    health_index    DOUBLE,
    ne107_status    VARCHAR(32),
    contributing_evidence_json JSON,                             -- never a bare "anomaly detected"
    model_version   VARCHAR(64),
    PRIMARY KEY (tenant_id, subject_urn(191), assessed_ts)
);

CREATE TABLE IF NOT EXISTS rul_estimate (
    subject_urn     VARCHAR(512) CHARACTER SET ascii NOT NULL,
    tenant_id       VARCHAR(191) CHARACTER SET ascii NOT NULL,
    estimated_ts    DATETIME(6) NOT NULL,
    failure_mode_id VARCHAR(191) CHARACTER SET ascii,            -- RUL is always RUL *against a failure mode*
    rul_point       DOUBLE,
    rul_p10         DOUBLE,                                      -- a point estimate alone is not
    rul_p90         DOUBLE,                                      -- actionable and not defensible
    unit            VARCHAR(32) NOT NULL DEFAULT 'days',
    model_id        VARCHAR(191),
    model_version   VARCHAR(64),
    assumed_duty_json JSON,
    PRIMARY KEY (tenant_id, subject_urn(191), estimated_ts)
);


-- ── EXPLICIT ABSENCE ───────────────────────────────────────────────────────
-- Storing absence is not optional. A model that cannot tell "zero" from "no
-- data" from "sensor removed" will produce confident nonsense, and every
-- aggregate silently averages the gap away.
CREATE TABLE IF NOT EXISTS data_gap (
    gap_id       VARCHAR(191) CHARACTER SET ascii PRIMARY KEY,
    tenant_id    VARCHAR(191) CHARACTER SET ascii NOT NULL,
    point_id     VARCHAR(191) CHARACTER SET ascii,
    asset_id     VARCHAR(256) CHARACTER SET ascii,
    signal       VARCHAR(512) CHARACTER SET ascii,
    start_ts     DATETIME(6) NOT NULL,
    end_ts       DATETIME(6),
    cause        VARCHAR(64) NOT NULL,          -- outage|maintenance|comms|device-down|not-commissioned
    backfilled   TINYINT(1) NOT NULL DEFAULT 0,
    INDEX idx_gap_point (tenant_id, point_id, start_ts DESC)
);


-- ── VERIFIED OBSERVATIONS ──────────────────────────────────────────────────
-- Deliberately a SECOND table rather than new columns on `measurements`.
-- `measurements` is bronze: immutable, exactly as received, primary key doubling
-- as the idempotency contract for replayed edge buffers. Adding mutable quality
-- columns to it would break that guarantee. Silver is derived and recomputable
-- from bronze plus versioned code, which is precisely what makes an audit
-- defensible — so it gets its own table and can be rebuilt at will.
--
-- Populate this only when L0–L2 verification actually exists. Until then the
-- existing OPC `quality` byte on `measurements` is the honest state of play.
CREATE TABLE IF NOT EXISTS measurements_verified (
    tenant_id     VARCHAR(191) CHARACTER SET ascii NOT NULL,
    point_id      VARCHAR(191) CHARACTER SET ascii NOT NULL,
    valid_ts      DATETIME(6) NOT NULL,
    value         DOUBLE,
    unit_code     VARCHAR(64) NOT NULL DEFAULT '',
    quality_flags BIGINT NOT NULL DEFAULT 0,    -- one bit per L0–L7 condition
    trust_score   DOUBLE NOT NULL DEFAULT 1.0,  -- [0,1]; consumers set their own floor
    ne107_status  VARCHAR(32) NOT NULL DEFAULT 'OK',
    correction_id VARCHAR(191) CHARACTER SET ascii,   -- corrections are ADDITIVE, never overwrites
    estimator_id  VARCHAR(191) CHARACTER SET ascii,   -- set = this value came from a virtual sensor
    source_ts     DATETIME(6),                        -- device clock
    tx_ts         DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),  -- when the platform learned it
    PRIMARY KEY (tenant_id, point_id, valid_ts),
    INDEX idx_verified_trust (tenant_id, point_id, trust_score)
);
