# Data modelling for the twin — assessment, template and adoption path

Three things live in this folder:

| File | What it is |
|------|-----------|
| [TEMPLATE.asset-class.yaml](TEMPLATE.asset-class.yaml) | The fill-in template. **One file per asset class.** |
| [EXAMPLE.datacenter-crah.yaml](EXAMPLE.datacenter-crah.yaml) | The template filled in for `dc:CRAHUnit`, an asset this repo already ships. |
| [measurement-point-register.csv](measurement-point-register.csv) | The spreadsheet form of §4 — the one artefact a site engineer can actually complete. |
| [master-data.sql](master-data.sql) | Proposed DDL for the master-data tables the platform does not have yet. Design artefact, not a migration. |
| [JOB-SPEC.data-engineer.md](JOB-SPEC.data-engineer.md) | The handover brief: what the data engineer builds, what they must *not* fill in themselves, and who sources each class of value. |

---

## 1. Is the canonical-data-model spec good enough for this project?

**Yes — as a target model and an acceptance checklist. No — as a build plan.**

It is a genuinely strong specification. It is standards-correct, and more usefully it names
the specific traps that kill twin platforms in month six rather than month one: conflating the
measured world with the believed world, keying trends on sensors instead of points, thresholds
as config literals, never capturing the operator's verdict on an alert.

The mismatch is that it is written for a greenfield platform, and this one is not greenfield.
Followed literally, it would have you rebuild things that already work here — and in a couple
of places rebuild them worse.

**What this repo already satisfies, in some cases better than the spec asks:**

- **P1, one core with domain profiles.** This is literally the pack architecture. `packs/<domain>/`
  co-locates TTL + physics + behaviours + predict, and `nxr-classes.ttl` carries an explicit
  freeze rule: packs extend downward, never edit the core. The spec's "if a vertical needs a
  schema change, the core is under-generalised" is already enforced structurally.
- **The semantic plane.** BFO + SOSA grounding, `nxr:taxonomyCategory` closing the label set that
  becomes the Neo4j label, a SHACL gate over the shapes.
- **The advisory chain.** `Finding → Incident → Diagnosis → Recommendation → Action` is already in
  `nxr-classes.ttl` — that is ISO 13374's state-detection→advisory pipeline, modelled.
- **Typed ports and edges.** `nxr:hasPort`, `nxr:connectsTo`, `feeds` / `fedBy` / `dependsOn`. The
  spec calls impact analysis over these edges "the product"; the graph is already there.
- **Bronze discipline in the historian.** `measurements` carries the OPC quality byte from day one,
  with the reasoning written down, and rollups report `count`/`sum` rather than `avg` so a coarser
  bucket cannot silently skew a chart. That is better than most implementations of this spec.
- **Prognostics.** `health_index` and RUL already exist across the packs.

So the platform is strong at the semantic end *and* at the physics/prognostics end, and thin
in the middle. That is an unusual shape, and it means the spec's phase ordering does not apply
to you as written.

**What is genuinely missing** (verified against the code, not assumed):

| # | Gap | Consequence today |
|---|-----|-------------------|
| 1 | No `MeasurementPoint` / `SensorType` / `SensorInstance` split — the historian keys on `(tenant_id, asset_id, signal)` | A sensor swap lands as a step change in the trend and corrupts the baseline. Sensor-health analytics is structurally impossible — there is no sensor to be healthy. |
| 2 | Thresholds are literals inside `nxr:monitoringRules` JSON (`datacenter-bindings.ttl:13`, `bound: 26`; `:21`, `bound: 300`) | No limit has a basis, an owner, an approval or a history. Nobody can answer "why 300?" or "what do I do when it fires?" |
| 3 | No verified-observation tier — raw only, no quality flags, no trust score | Every consumer implicitly trusts every value equally. A degraded sensor can raise a critical alarm. |
| 4 | No `AlertDisposition` | No labels. Precision is unmeasurable, thresholds are untunable with evidence, and supervised learning is permanently out of reach. |
| 5 | No calibration record, so no as-found values | The only direct measurement of sensor drift is never captured. |
| 6 | No `FunctionalLocation` distinct from `Asset` | After the first equipment swap you can answer neither "how does this position behave?" nor "how has this unit behaved?" |
| 7 | No explicit `DataGap` | "No data" silently becomes "zero" in every aggregate. |

A concrete symptom of all of the above, found while writing the example: **`cfp:filterDeltaP` is
used in four places** — `feed/simulate_cfp.py:143`, `dynamics/models/hvac.py:35`,
`behaviors/cfp/tier_c_filter.py:14`, and two `*-bindings.ttl` threshold rules — **and declared in
none.** It is not a `sosa:ObservableProperty` anywhere in the ontology. So nothing in the system
knows its unit, its plausible range, or which failure mode it detects. It works, because a string
matches a string. That is the gap in one line.

**What to deliberately *not* take from the spec, at least not now:**

- **The five-plane architecture with a Kafka event spine and a columnar TSDB.** `historian/schema.py`
  already states this trade-off explicitly and chose a plain MySQL table on purpose. That reasoning
  still holds. Revisit at volume, not before.
- **Bitemporality everywhere.** Expensive and invasive. Apply it to thresholds and corrections —
  where "what limit was in force at 14:32?" is a real question after an incident — and nowhere else yet.
- **L5 data reconciliation.** The strongest tool in the spec and the most work. It needs redundant
  metering to be worth anything. It is a superb data-centre power-tree demo *later*; it is not a
  starting point.
- **All 17 entity groups / ~70 entities.** Roughly twelve tables close most of the value. The rest
  is a catalogue to check yourself against, not a backlog.

---

## 2. How to model the data — the method

The one rule that matters, because it inverts how nearly everyone does it:

> **Derive measurements from the failure modes you intend to detect. Never list the sensors that
> happen to be on the machine and then invent uses for them.**

A signal with no failure mode behind it is storage cost. A failure mode with no signal is a blind
spot — and you should be able to *query for it* rather than discover it during an outage.

So the fill order in the template is not cosmetic:

```
§3 failure modes  →  §4 measurement points  →  §5 sensors  →  §6 thresholds  →  §7 verification  →  §8 degradation
     what breaks       what must be observed    what to buy      when to shout       is it true?        how long left
```

Four distinctions do most of the work. Get these wrong and no amount of later engineering repairs it:

1. **Point ≠ Sensor.** A point is a *requirement* (property, location, range, accuracy, rate) and lives
   as long as the plant. A sensor is a *solution* and gets replaced every few years. Trends,
   baselines and thresholds belong to the point; calibration, drift and RUL belong to the instance.
2. **FunctionalLocation ≠ Asset.** The position in the process versus the machine bolted there today.
3. **Raw ≠ Verified ≠ Estimated.** Three records for what looks like one number: as received
   (immutable), plus quality and corrections, and what the twin *believes* — which may come from a
   virtual sensor with no hardware behind it at all.
4. **Sensor fault ≠ Asset fault.** A drifting sensor read as a dying machine raises a work order
   against healthy equipment. §8 of the template encodes the discrimination as explicit evidence rules.

---

## 3. What you actually need — the minimum viable dataset

Per asset class, this is the floor. Everything else in the template is refinement.

- **Asset class + failure modes** — ISO 14224 taxonomy, mechanism, development time, consequence.
  Including the honest list of failure modes nothing currently detects.
- **Measurement points** — tag, observable property, canonical unit, purpose class, plausible range,
  slew limit, expected interval, which failure modes each one detects.
- **Operating modes** — startup / steady / standby / maintenance, with entry conditions. Without
  these, every threshold is either deaf or screaming, and the N+1 spare alarms all day.
- **Thresholds with a basis and a corrective action** — the ISA-18.2 test is "what does the operator
  *do* when this fires?" No answer means delete it.
- **Sensor type metrology** — range, accuracy, response t90, drift spec. These are not paperwork:
  t90 sets the stuck-detection window, and the drift spec is the prior for the degradation model.
- **Maintenance and failure history** — the CMMS record. Without it the predictive layer is
  unsupervised forever.
- **Alert dispositions** — one tap per closed incident. Cheapest, highest-return field in the model.

---

## 4. How to proceed

Three steps, in order. Each is independently useful, and none requires the next to be worth doing.

**Step 1 — Model three to five asset classes on paper.** Rank by criticality × population; do not
attempt the whole plant. Copy the template per class and fill it, failure modes first. Expect this
to take weeks, not months, and expect §3 to produce arguments — those arguments are the deliverable.
The output includes an instrumentation gap report ("these failure modes are undetectable today"),
which is a finding worth selling rather than an embarrassment to hide.

**Step 2 — Land the master-data layer.** Review [master-data.sql](master-data.sql), then move it into
`db/schema.py` in the house idiom. Two properties make this cheap: `measurement_point` carries both
the canonical `point_id` *and* the existing `(asset_id, signal)` pair, so the historian keeps its
primary key and its writers untouched — the four-level sensor model arrives as a join, not a
breaking change. And `measurements_verified` is a separate table, so bronze stays immutable and
silver stays recomputable. Alongside it, in the ontology: declare `cfp:filterDeltaP` and the other
undeclared properties, and add the failure-mode classes as `nxr:FailureMode` subclasses.

Thresholds move out of the `monitoringRules` literals into governed rows, keeping `behavior_id` as
the link — so every existing behaviour keeps firing exactly as it does now, and gains a basis, an
owner and an audit trail. Nothing regresses on the day you switch.

**Step 3 — Turn on verification L0–L3 and disposition capture.** Range, stuck, spike, slew,
staleness, clock skew. Cheap checks that catch most bad data, plus one tap in the incident panel for
the operator's verdict. From there, `min_trust_required` starts doing real work and thresholds stop
firing on rubbish.

Only after that is L4/L5 (redundancy, reconciliation), full bitemporality, or a fault-injection
harness worth the effort. The spec's own build sequence agrees — it just assumes you are starting
from nothing, and you are not.
