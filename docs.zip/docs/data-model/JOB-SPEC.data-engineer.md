# Job spec — data engineer, twin reference-data layer

## The one-line brief

> Build the mechanism that makes every engineering value in the twin **sourced, auditable and
> self-improving**. Do not source the values yourself.

That distinction is the whole job. A drift rate, a threshold or an expected life is a claim about
the physical world. If a data engineer fills those in from judgement, the result is dimensionally
perfect nonsense that no downstream check can catch, and it propagates silently into RUL and alarm
priority. Blanks are recoverable; invented numbers are not.

So: **the data engineer owns the pipeline and the provenance. Domain sources own the numbers.**

---

## Deliverables

### D1 — Type catalogues with provenance as a first-class column

Implement `sensor_type`, `sensor_instance`, `measurement_point`, `point_sensor_assignment`,
`threshold`, `calibration_record` from [master-data.sql](master-data.sql).

The addition that is not in that file yet, and is the point of this job: **every engineering value
carries its own provenance**, not just the row. Either a JSON envelope per value —

```json
{ "v": 0.05, "src": "T1", "ref": "Vendor datasheet PN-4471 rev C, table 2", "on": "2026-08-20" }
```

— or a sidecar `value_provenance(table, row_id, field, src, ref, sourced_on, expires)` table if you
prefer to keep the columns numeric for querying. Either is fine; pick one and be consistent.

Tiers, defined in §0 of [TEMPLATE.asset-class.yaml](TEMPLATE.asset-class.yaml):
`T0 measured · T1 vendor · T2 standard · T3 family default · T4 assumed`.

**A missing provenance defaults to T4, never to "fine".** Unsourced must fail loud.

*Acceptance:* `SELECT` returns every value currently at T4 or expired, grouped by asset class, in
one query. That query is the backlog for whoever sources the numbers.

### D2 — The transducer-family seed

Load the family-level reference table (~12–14 rows: thermal-resistive, thermal-thermoelectric,
piezoelectric, capacitive, inductive/magnetic, electrochemical-amperometric,
electrochemical-potentiometric, optical-absorption, acoustic, flow-inferential, strain-gauge, MEMS,
catalytic, virtual) with degradation mechanism, dominant signature, indicative life and indicative
drift rate — all tagged **T3**.

This is the highest-leverage day of the whole job. Every pack inherits it, across all four
verticals, and it means no sensor ever has a truly empty degradation model — just a defensible
default that is honestly labelled as a default.

*Acceptance:* a new `sensor_type` row with only `transducer_family` set resolves a complete
degradation model at T3, and says so.

### D3 — Ingestion for the two authoritative sources

- **Vendor datasheets → T1.** A structured intake (form, CSV, or parse-assisted) that will not
  accept a value without a document reference *and revision*. Specs change between revisions;
  "the datasheet" is not a citation.
- **Standard clauses → T2.** A `standard_clause` library keyed by clause, so a threshold's basis is
  a foreign key rather than a sentence. ISO 20816 vibration zones, ASHRAE TC9.9 envelopes and
  classes, ISO 6469 insulation limits, ASHRAE 170 pressure and ACH, ISO 7396 gas pressures.

*Acceptance:* a threshold row can name its basis clause, and the clause resolves to real text.
Nobody can approve a threshold whose basis is prose.

### D4 — The as-found calibration loop (the part that makes values converge)

This is the deliverable that changes the answer to "are these numbers correct" from *no* to
*increasingly*.

1. Import calibration records from the customer's CMMS/calibration system, capturing **as-found and
   as-left separately**. Most organisations record only as-left, which throws away the only direct
   measurement of drift there is — flag as-found-missing as a data-quality defect, loudly.
2. Fit drift per instance, with the type-level spec as a Bayesian prior.
3. When three or more as-found records exist for a type, **promote the type's drift spec from T1/T3
   to T0** and record the promotion.
4. Recompute next-calibration-due so that `P(|drift| > MPE before next cal) < α`, with α set by the
   point's purpose class — safety and regulatory tight, analytics loose.

*Acceptance:* a report showing, per sensor type, how its drift spec has moved from assumed toward
measured — and where intervals lengthened or shortened as a result. Lengthened intervals are direct,
provable cost savings and the easiest commercial conversation you will have.

### D5 — Validation in CI

Fail the build on:

- a measurement point whose `detects` is empty, or names a failure mode that does not exist;
- a failure mode with no detecting point *and* no explicit `detectability: blind` (a blind spot must
  be declared, not implied);
- a threshold with no `basis`, no `corrective_action`, or no owner;
- a point with `purpose_class` in (safety, regulatory) and `min_trust_required < 0.99`;
- a `signal_key` that does not exist in the pack's `SIGNALS`;
- an observable property used in a binding but not declared in the ontology — **there is at least
  one of these today**: `cfp:filterDeltaP` is referenced in four places and declared in none;
- any T4 value past its `expires` date.

*Acceptance:* CI is red on a real violation today, and the fix is to source the value, not to
weaken the rule.

### D6 — The provenance report

A single page or endpoint: per asset class, the count at each tier, the oldest unsourced value, and
the T4 items ranked by blast radius — a drift rate feeding a safety-classified point outranks one
feeding an analytics point.

*Acceptance:* you can open it in a review and know what to chase, without asking anyone.

---

## Explicitly not this job

Hand these to the people who can actually source them. If the data engineer is filling these in,
something has gone wrong.

| Value | Who sources it | Where it comes from |
|---|---|---|
| Sensor drift rate, accuracy, t90, expected life | Instrumentation engineer, or anyone able to read a datasheet accurately | The OEM datasheet at a stated revision |
| Vibration, thermal, pressure limits | Whoever holds the standards | ISO 20816, ASHRAE TC9.9 / 170, ISO 6469, ISO 7396 — these are purchases, budget for them |
| Failure modes, mechanisms, development times | Reliability engineer + the site's own maintenance history | ISO 14224 taxonomy + FMEA + the customer's failure records |
| Site-specific limits and criticality | The site's own engineer | Cannot be outsourced. "This machine runs hot by design" is knowledge only they have |
| Consequence, corrective action, time to respond | Operations | The alarm response procedure |
| Downtime cost per hour | The customer's commercial side | Without it there is no prioritisation and no ROI story |

A useful rule for the handover: **the data engineer may never be the `ref` on a value.** If the
citation would be a person's judgement, it is T4 and it needs an expiry date and an owner.

---

## Sequencing

Do not wait for correct numbers to start. The order that works:

1. **D1 + D2 first.** Land the tables and seed the family defaults. Now every sensor has a
   degradation model at T3 — defensible, and honestly labelled as a default. The twin runs.
2. **D5 next.** Turn on validation while the violation count is small enough to fix.
3. **D3 in parallel** with the domain sourcing work. As datasheets and clauses arrive, T4 and T3
   values become T1 and T2. Nothing downstream changes shape.
4. **D4 last**, and only where calibration records actually exist. This is where values stop being
   claims and start being measurements — but it needs a customer with real calibration history, so
   it is deployment-gated, not development-gated.
5. **D6 throughout**, because it is how you know whether any of the above is working.

## What to hand over on day one

- [TEMPLATE.asset-class.yaml](TEMPLATE.asset-class.yaml) — §0 is the part that governs this job
- [EXAMPLE.datacenter-crah.yaml](EXAMPLE.datacenter-crah.yaml) — what "filled in" looks like, including
  values deliberately marked as needing a site figure
- [master-data.sql](master-data.sql) — the starting schema
- [measurement-point-register.csv](measurement-point-register.csv) — the intake format for site data
- [README.md](README.md) — why any of this exists

## Definition of done

Not "the values are correct" — that is not achievable on any timeline, and promising it is how this
work gets discredited. Done is:

> Every engineering value in the twin can state where it came from and how much to trust it; the
> unsourced ones are visible and ranked; and the ones that can improve by themselves are wired to
> the calibration data that improves them.
